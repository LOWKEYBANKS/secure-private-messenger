package com.bitchat.android.net

enum class TorMode {
    OFF,
    ON
}

